import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Users, UserAssigns, Stores, Company, SeriesbyUser, Series} from '../../../../models/index';
import { BlockUI, NgBlockUI } from 'ng-block-ui';
import {PermsService, ItemService, UserService, SeriesService, SalesManService, AlertService} from '../../../../services/index';
import { FormGroup, FormBuilder, Validators, FormControl } from '@angular/forms';
import { Router } from '@angular/router';
import { SerieService } from '../../../../services/serie.service';

@Component({
  selector: 'app-user-conf',
  templateUrl: './user-conf.component.html',
  styleUrls: ['./user-conf.component.scss']
})
export class UserConfComponent implements OnInit {
  @BlockUI() blockUI: NgBlockUI;
  userId: number;
  userinfo: UserAssigns;
  userList: Users [] = [];
  userAssignsList: UserAssigns [] = [];
  storesList: Stores [] = [];
  companyList: Company [] = [];
  serieList: Series [] = [];
  InvSerieList: Series [] = [];
  QuoSerieList: Series [] = [];
  IpaySerieList: Series [] = [];
  SOSerieList: Series[] = [];
  ncSerieList: Series[];
  CustomerSerieList: Series[]=[];
  SupplierSerieList: Series []=[];
  ApInvoiceSerieList: Series []=[];
  ApPaymentSerieList: Series []=[];

  userGroup: FormGroup;
  // Id: number;
  disable: boolean;
  salida: boolean;
  btnSendInfo: string; // cambia el titulo de el boton de envio
  PriceList: any[] = []; // lista de las listas de precios
  SalesPersonList: any [] = [];

  constructor(private activatedRoute: ActivatedRoute,
              private pService: PermsService,
              private uService: UserService,
              private sService: SeriesService,
              private fbg: FormBuilder,
              private router: Router,
              private itemService: ItemService,
              private smService: SalesManService,
              private alertService: AlertService,
              private serieService: SerieService ) {
    // this.Id = 0;
    console.log(0);
    this.userinfo = new UserAssigns();
  }

  ngOnInit() {
    // tslint:disable-next-line:radix
    this.userId = parseInt(this.activatedRoute.snapshot.paramMap.get('userId'));
    this.disable = false;
    this.salida = true;
    if (this.userId > 0) {
      this.disable = true;
      this.btnSendInfo = 'Actualizar';
    } else { this.btnSendInfo = 'Crear'; }

    this.userGroup = this.fbg.group({
      cUserName: [{value: '', disabled: this.disable}, [Validators.required]],
      cSAPUser: ['', [Validators.required]],
      SAPPass: ['', [Validators.required]],
      StoreId: [ '', [Validators.required]],
      CompanyId: [{value: '', disabled: this.disable}, [Validators.required]],
      minDiscount: ['', [Validators.required, Validators.max(100), Validators.min(0)]],
      SlpCode: ['', [Validators.required]],
      CenterCost: [''],
      PriceListDef: ['', [Validators.required]],
      InvSerie: ['', [Validators.required]],
      IPaySerie: ['', [Validators.required]],
      QuoSerie: ['', [Validators.required]],
      SOSerie: ['', [Validators.required]],
      NcSerie: ['', [Validators.required]],
      CustomerSerie: ['', [Validators.required]],
      SupplierSerie: ['', [Validators.required]],
      ApInvoiceSerie: ['', [Validators.required]],
      ApPaymentSerie: ['', [Validators.required]],
      Active: [''],
      SuperUser: ['']
    });
    this.chargeUser();

    this.serieService.getSeries().subscribe(response => {
      this.ncSerieList = response.Series.filter(x => {
        const serie = {} as Series;
        if (x.DocType === 7) {
          serie.Active = x.Active;
          serie.CompanyId = x.CompanyId;
          serie.CompanyName = x.CompanyName;
          serie.DocType = x.DocType;
          serie.Id = x.Id;
          serie.Name = x.Name;
          serie.Numbering = x.Numbering;
          serie.Serie = x.Serie;
          serie.typeName = x.typeName;
          return serie;
        }
      });
    });
  }
// carga la informacion de los usuarios en el dropdown de usuarios
// parametro -> no recive.
  chargeUser() {
    this.blockUI.start('Cargando listas de usuarios...');
    this.pService.getUsers().subscribe((data: any) => {
      this.blockUI.stop();
      if (data.result) {
        this.userList = data.users;
        
        if ( this.userId > 0) {this.chargeUserAsing(); }
        this.getGetCompanies();
        this.userGroup.patchValue({cUserName: this.userList[0].Id});
      } else {
        this.alertService.errorAlert('Error al cargar la lista de usuarios - ' + data. errorInfo.Message);
      }
    }, error => {
      this.blockUI.stop();
      this.alertService.errorInfoAlert(`Error al intentar conectar con el servidor, Error: ${error}`);
    });
  }
  // obtiene las compañias de las cuales dispone la empresa.
  // parametro -> no recive.
  getGetCompanies() {
    this.blockUI.start('Cargando listas de almacenes...');
    this.uService.getGetCompanies().subscribe((data: any) => {
      this.blockUI.stop();
      if (data.result) {
        this.companyList = data.companiesList;
        this.userGroup.patchValue({CompanyId: this.companyList[0].Id});
        this.getStoresList(this.companyList[0].Id);
      } else {
        this.alertService.errorAlert('Error al cargar la lista de almacenes - ' + data. errorInfo.Message);
      }
    }, error => {
      this.blockUI.stop();
      this.alertService.errorInfoAlert(`Error al intentar conectar con el servidor, Error: ${error}`);
    });

  }
// obtiene las tiendas que pertenecen a la compañia seleccionada.
// parametro -> recibe el numero de compañia
  getStoresList(company: number) {
    this.blockUI.start('Cargando listas de Almacenes...');
    this.uService.getStoresList(company).subscribe((data: any) => {
      this.blockUI.stop();
      if (data.result) {
        this.storesList.length = 0;
        this.storesList = data.Stores;
        this.userGroup.patchValue({StoreId: this.storesList[0].Id});
        this.chargeSeriesList();

      } else {
        this.alertService.errorAlert('Error al cargar la lista de Almacenes - ' + data. errorInfo.Message);
      }
    }, error => {
      this.blockUI.stop();
      this.alertService.errorInfoAlert(`Error al intentar conectar con el servidor, Error: ${error}`);
    });

  }

  get f() { return this.userGroup.controls; }
  // cambia las sucursales en caso de que se cambie la compañia
  // parametro -> no recive.
  onCompanyChange() {
    this.storesList.length = 0;
    this.getStoresList(this.userGroup.controls.CompanyId.value);
  }

  // carga la informacion del usuario en caso que sea opcion de ediccion
  // parametro -> no recive.
  chargeUserAsing() {
    this.blockUI.start('Cargando listas de usuarios...');
    this.uService.getUserList().subscribe((data: any) => {
      this.blockUI.stop();
      if (data.result) {
        this.userAssignsList = data.Users;
      } else {
        this.alertService.errorAlert('Error al cargar la lista de usuarios - ' + data. errorInfo.Message);
      }
    }, error => {
      this.blockUI.stop();
      this.alertService.errorInfoAlert(`Error al intentar conectar con el servidor, Error: ${error}`);
    });
  }

  // carga la informacion del usuarios en los formscontrols
  // parametro -> recivel el ID de usuario
  chargeUserData(Id: number) {
    this.userAssignsList.forEach(user => {
      if ( Id === user.Id) {
        this.userList.forEach( us => {
          if (us.Id.toString() === user.UserId) {
            this.userGroup.patchValue({cUserName: us.Id});
          }
        });
        this.userGroup.controls.cSAPUser.setValue(user.SAPUser);
        this.userGroup.patchValue({CompanyId: user.CompanyId});
        this.userGroup.patchValue({StoreId: user.StoreId});
        this.userGroup.patchValue({PriceListDef: user.PriceListDef});
        this.userGroup.controls.minDiscount.setValue(user.minDiscount);
        // this.userGroup.controls.SlpCode.setValue(user.SlpCode);
        this.userGroup.patchValue({SlpCode: user.SlpCode});
        this.userGroup.controls.SAPPass.setValue(user.SAPPass);
        this.userGroup.controls.CenterCost.setValue(user.CenterCost);
        this.userGroup.controls.Active.setValue(user.Active);
        this.userGroup.controls.SuperUser.setValue(user.SuperUser);
        this.salida = false;
        user.Series.forEach( serie => {
          if ( serie.type === 1) {
            this.userGroup.patchValue({InvSerie: serie.SerieId});
          }
          if ( serie.type === 2) {
            this.userGroup.patchValue({QuoSerie: serie.SerieId});
          }
          if ( serie.type === 3) {
            this.userGroup.patchValue({IPaySerie: serie.SerieId});
          }
          if ( serie.type === 5) {
            this.userGroup.patchValue({CustomerSerie: serie.SerieId});
          }
          if ( serie.type === 6) {
            this.userGroup.patchValue({SupplierSerie: serie.SerieId});
          }
          if ( serie.type === 7) {
            this.userGroup.patchValue({NcSerie: serie.SerieId});
          }
          if ( serie.type === 8) {
            this.userGroup.patchValue({ApInvoiceSerie: serie.SerieId});
          }
          if ( serie.type === 9) {
            this.userGroup.patchValue({ApPaymentSerie: serie.SerieId});
          }
        });
      }
    });
    if (this.salida) { this.router.navigate(['users']); }
  }

  // envia la info al api para guardarla en internet.
  // parametro -> no recive.
  onSubmitCreate() {
     // let userName = '';
    this.blockUI.start('Registrando Datos...');
    // this.userList.forEach(user => {
    //   if (user.Id === this.userGroup.controls.cUserName.value) {
    //       userName = user.UserName;
    //   }
    // });
    
    this.uService.sendUserInfo(this.userGroup, this.userGroup.controls.cUserName.value, this.userId);
  }
  // trae la informacion de las series de numeracion y lo guardan en listas segun
  // su tipo para mostrar en el dropdow respectivo
  // parametro -> no recive.
  chargeSeriesList() {
    this.blockUI.start('Cargando listas de series..');
    this.sService.getSeriesList().subscribe((data: any) => {
      this.blockUI.stop();
      if (data.result) {
        this.serieList = data.Series;
        this.ChargeSeriesListbyType();
        this.GetPriceList();
      } else {
        this.alertService.errorAlert('Error al cargar la lista de series - ' + data. errorInfo.Message);
      }
    }, error => {
      this.blockUI.stop();
      this.alertService.errorInfoAlert(`Error al intentar conectar con el servidor, Error: ${error}`);
    });
  }

  // separa las series de numeracion por tipo de serie, si es pago o facturacion  cotizacion
  // REVC -> POR EL MOMENTO SE LE ASIGNA UN NUMERO POR QUE NO ENCONTRE MANERA DE ASIGNAR EL DATO CORRECTO
  // YA QUE LOS ENUMS VIENEN DESDE EL BACKEND - IDEAS?
  // parametro -> no recive.
  ChargeSeriesListbyType() {
      this.serieList.forEach( serie => {
      if ( serie.DocType === 1) {
        this.InvSerieList.push(serie);
      }
      if ( serie.DocType === 2) {
        this.QuoSerieList.push(serie);
      }
      if ( serie.DocType === 3) {
        this.IpaySerieList.push(serie);
      }
      if ( serie.DocType === 4) {
        this.SOSerieList.push(serie);
      }
      if ( serie.DocType === 5) {
        this.CustomerSerieList.push(serie);
      }
      if ( serie.DocType === 6) {
        this.SupplierSerieList.push(serie);
      }
      if ( serie.DocType === 8) {
        this.ApInvoiceSerieList.push(serie);
      }
      if ( serie.DocType === 9) {
        this.ApPaymentSerieList.push(serie);
      }
    });
	
	if(this.InvSerieList.length){
		this.userGroup.patchValue({InvSerie: this.InvSerieList[0].Id});
	}
	if(this.QuoSerieList.length){
		this.userGroup.patchValue({QuoSerie: this.QuoSerieList[0].Id});
	}
	if(this.IpaySerieList.length){
		this.userGroup.patchValue({IPaySerie: this.IpaySerieList[0].Id});
	}
	if(this.SOSerieList.length){
		this.userGroup.patchValue({SOSerie: this.SOSerieList[0].Id});
  }
  if(this.CustomerSerieList.length){
		this.userGroup.patchValue({CustomerSerie: this.CustomerSerieList[0].Id});
	}
  if(this.SupplierSerieList.length){
		this.userGroup.patchValue({SupplierSerie: this.SupplierSerieList[0].Id});
  }
  if(this.ApInvoiceSerieList.length){
		this.userGroup.patchValue({ApInvoiceSerie: this.ApInvoiceSerieList[0].Id});
  }
  if(this.ApPaymentSerieList.length){
		this.userGroup.patchValue({ApPaymentSerie: this.ApPaymentSerieList[0].Id});
	}


  }

  // trae la lista de precios para seleccionar cualquiera en la vusta de facturacion
  GetPriceList() {
    this.blockUI.start('Obteniendo Listas de precios, Espere Por Favor...'); // Start blocking
    this.itemService.GetPriceList()
    .subscribe( (data: any) => {
      if (data.result) {
        this.PriceList = data.priceList;
        this.userGroup.patchValue({PriceListDef: this.PriceList[0].ListNum});
        this.GetSalesPersonList();
      } else {
        this.alertService.errorAlert(`Error: Código: ${data.errorInfo.Code}, Mensaje: ${data.errorInfo.Message}`);
      }
      this.blockUI.stop(); // Stop blocking
    }, (error: any) => {
      this.blockUI.stop(); // Stop blocking
      this.alertService.errorInfoAlert(`Error al intentar conectar con el servidor, Error: ${error}`);
    });
  }

  GetSalesPersonList() {
    this.blockUI.start('Obteniendo vendedores, Espere Por Favor...'); // Start blocking
    this.smService.getSalesMan()
    .subscribe( (data: any) => {
      if (data.result) {
        this.SalesPersonList = data.salesManList;
        console.log(this.SalesPersonList, this.SalesPersonList[0].SlpCode);
        this.userGroup.patchValue({SlpCode: this.SalesPersonList[0].SlpCode});
        if (this.userId > 0) { this.chargeUserData(this.userId); }
      } else {
        this.alertService.errorAlert(`Error: Código: ${data.errorInfo.Code}, Mensaje: ${data.errorInfo.Message}`);
      }
      this.blockUI.stop(); // Stop blocking
    }, (error: any) => {
      this.blockUI.stop(); // Stop blocking
      this.alertService.errorInfoAlert(`Error al intentar conectar con el servidor, Error: ${error}`);
    });
  }
  cancel(){
    this.router.navigate(['/AssignsUsers']);
  }

}
